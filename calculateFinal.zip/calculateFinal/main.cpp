#include <iostream>
#include "LStack.h"
#include "getInput.h"
#include "optr.h"
#include <string>
#include<math.h>

using namespace std;

double getResult(char[]);

int whichOptr(int, int, char);

int main() {

    char *expression = getExpression();
    if (expression == NULL) {
        cout << "expression is NULL" << endl;
    } else {
        double result = getResult(expression);
        cout << result << endl;
    }

    return 0;
}

double getResult(char *in) {
    LStack<char> *optr = new LStack<char>;
    LStack<double> *opnd = new LStack<double>;
    optr->push('=');
    for (int i = 0; !((in[i] == '\0') && (optr->topValue() == '=')); i++) {
        cout << "���ڴ���" << in[i] << endl;
        while (in[i] == '\0' && optr->topValue() != '=') {
            int numberA = opnd->pop();
            int numberB = opnd->pop();
            int temp = whichOptr(numberB, numberA, optr->pop());
            opnd->push(temp);
        }
        if (in[i] >= '0' && in[i] <= '9') {
            int t = in[i] - '0';
            opnd->push(t);
            while (in[i + 1] >= '0' && in[i + 1] <= '9') {
                i++;
                int ret = opnd->pop() * 10 + (in[i] - '0');
                opnd->push(ret);
            }
            if (in[i + 1] == '.') {
                i += 2;
                int j = 1;
                while (in[i] >= '0' && in[i] <= '9') {
                    double ret = opnd->pop() + (in[i] - '0') / pow(10.0, j++);
                    opnd->push(ret);
                    i++;
                }
            }
        } else if (in[i] != '\0') {
            if (optr_level_in(optr->topValue()) < optr_level_out(in[i])) {
                optr->push(in[i]);
            } else if (optr_level_in(optr->topValue()) > optr_level_out(in[i])) {
                if (in[i] == ')') {
                    while (optr->topValue() != '(') {
                        int numberA = opnd->pop();
                        int numberB = opnd->pop();
                        int temp = whichOptr(numberB, numberA, optr->pop());
                        opnd->push(temp);
                        //
                        while (in[i + 1] >= '0' && in[i + 1] <= '9') {
                            i++;
                            int ret = opnd->pop() * 10 + (in[i] - '0');
                            opnd->push(ret);
                        }
                        if (in[i + 1] == '.') {
                            i += 2;
                            int j = 1;
                            while (in[i] >= '0' && in[i] <= '9') {
                                double ret = opnd->pop() + (in[i] - '0') / pow(10.0, j++);
                                opnd->push(ret);
                                i++;
                            }
                        }
                        //
                        i--;
                    }
                } else {
                    int numberA = opnd->pop();
                    int numberB = opnd->pop();
                    int temp = whichOptr(numberB, numberA, optr->pop());
                    opnd->push(temp);
                    //
                    while (in[i + 1] >= '0' && in[i + 1] <= '9') {
                        i++;
                        int ret = opnd->pop() * 10 + (in[i] - '0');
                        opnd->push(ret);
                    }
                    if (in[i + 1] == '.') {
                        i += 2;
                        int j = 1;
                        while (in[i] >= '0' && in[i] <= '9') {
                            double ret = opnd->pop() + (in[i] - '0') / pow(10.0, j++);
                            opnd->push(ret);
                            i++;
                        }
                    }
                    //
                    i--;

                }
            } else {
                optr->pop();
            }
        }
    }
    return opnd->topValue();
}

int whichOptr(int a, int b, char optr) {
    if (optr == '+') {
        cout << a << optr << b << endl;
        return a + b;
    }
    if (optr == '-') {
        cout << a << optr << b << endl;
        return a - b;
    }
    if (optr == '*') {
        cout << a << optr << b << endl;
        return a * b;
    }
    if (optr == '/') {
        cout << a << optr << b << endl;
        return a / b;
    }
    if (optr == '%') {
        cout << a << optr << b << endl;
        return a % b;//***************************�����㷨ֻ������b%a!!!!!!!!!
    }
    if (optr == '^') {
        cout << a << optr << b << endl;
        return pow(a, b);
    }
    if (optr == '&') {
        cout << a << optr << b << endl;
        int i, n, r;
        for (n = 1; n < a; n++) {
            r = 1;
            for (i = 0; i < b; i++) {
                r *= n;
            }
            if (r >= a)
                break;
        }
        if (r == a)
            return n;
        return 0;
    }
}

