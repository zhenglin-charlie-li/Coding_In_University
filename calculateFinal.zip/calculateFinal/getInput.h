//
// Created by Zhenglin Li on 2020/11/5.
//

#ifndef CALCULATE_GETINPUT_H
#define CALCULATE_GETINPUT_H

#endif //CALCULATE_GETINPUT_H

#include <iostream>
#include <string>
#include "vector"

using namespace std;

char *getExpression() {
    string str;
    cin >> str;
    char stringArray[30] = {0};
    for (int i = 0; i < str.length(); i++) {
        stringArray[i] = str[i];
    }
//    cout << stringArray << endl;
    int i = 0;
    bool hasEqual = false;
    for (; i < str.length(); i++) {
        if (str[i] == '=') {
            hasEqual = true;
            break;
        }
        if (!(stringArray[i] <= '9' && stringArray[i] >= '0') && stringArray[i] != '+' && stringArray[i] != '-' &&
            stringArray[i] != '*' && stringArray[i] != '/' && stringArray[i] != '(' && stringArray[i] != ')' &&
            stringArray[i] != '%' && stringArray[i] != '&' && stringArray[i] != '^' && stringArray[i] != '.') {
            cout << "ERROR, Input Invalid!" << endl;
            return NULL;
        }
    }
    int count = 0;
//    for (i = 0; i < str.length(); i++) {
//        if (str[i] == '(') {
//            count++;
//        }
//        if (str[i] == ')') {
//            count--;
//        }
//    }
//    if (count != 0) {
//        cout << "ERROR, Input Invalid!" << endl;
//        return NULL;
//    }
//    cout << "i 的值是" << i << endl;
    if (hasEqual == false) {
        cout << "There are no = " << endl;
        return NULL;
    } else if (hasEqual == true && i < str.length() - 1) {
        cout << "There are characters behind = " << endl;
        return NULL;
    } else {
        cout << "Your Input Is Valid" << endl;
        const int length = i;
//        cout << "length 的值是" << length << endl;
        static char result[50];
        for (i = 0; i < length; i++) {
            result[i] = stringArray[i];
        }
        result[i] = '\0';
//        cout << "expression to be calculated is: " << result << endl;
        return result;
    }
}
