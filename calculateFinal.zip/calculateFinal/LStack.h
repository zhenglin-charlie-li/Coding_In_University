//
// Created by Zhenglin Li on 2020/11/5.
//

#ifndef CALCULATE_LSTACK_H
#define CALCULATE_LSTACK_H

#endif //CALCULATE_LSTACK_H

#include "iostream"

#define DEFAULT_SIZE 100

using namespace std;
template<class E>
class Node {
public:
    E value;
    Node <E>*next;

    Node(E value, Node<E> *next = NULL) : value(value), next(next) {}

    Node(Node *nextNode = NULL) { next = nextNode; }
};
template<class E>
class LStack {
private:
    Node<E> *top;
    int size;
public:
    LStack(int size = DEFAULT_SIZE) {
        top = NULL;
        this->size = size;
    }

    ~LStack() {
        clear();
    }
    bool empty(){
        return 0==size;
    }
    void clear() {
        while (top != NULL) {
            Node<E> *temp = top;
            top = top->next;
            delete temp;
        }
        size = 0;
    }

    void push(const E& character) {
        top = new Node<E>(character, top);
        size++;
    }

    E pop() {
        if (top == NULL) {
            cout << "Stack Is Empty2" << endl;
            return 0;
        }
        E out = top->value;
        Node <E>*ltemp = top->next;
        delete top;
        top = ltemp;
        size--;
        return out;
    }

    const E& topValue() const {
        if (top == NULL) {
            cout << "Stack Is Empty1" << endl;
            return 0;
        }
        return top->value;
    }

    void print() {
        Node<E> *temp = top;
        while (temp != NULL) {
            cout << temp->value;
            temp = temp->next;
        }
    }
};